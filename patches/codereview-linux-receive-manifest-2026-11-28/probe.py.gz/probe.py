"""Issue #128: exact source methods, temporary SQLite, synthetic dependencies.
Run with the pinned magnolie_telefon.py; no product files are changed.
"""
import base64, hashlib, json, os, sqlite3, sys, tempfile, types, uuid
from pathlib import Path
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

CLASS = '    class _ConflictingAttachmentManifest(ValueError):\n        pass\n\n'
INIT = '            record_count = 0\n'
ADD = '''            descriptors = {}
            check_manifest = not personal_actor_contract.is_storage_peer(peer_id)
'''
CHECK_AT = '                record_count += len(staged["body"]["records"])\n'
CHECK = '''                if check_manifest and staged["body"].get("format", 1) >= 2:
                    for record in staged["body"]["records"]:
                        if record["kind"] != "note":
                            continue
                        for item in record["value"]["attachments"]:
                            metadata = (item["size"], item["mime"])
                            if descriptors.setdefault(item["sha256"], metadata) != metadata:
                                raise self._ConflictingAttachmentManifest("conflicting attachment manifest")
'''
REPLAY = '''                aggregate = self.stage_personal_batch(peer_id,
                    strict_json(self._decrypt(row[0], "personal_batch", primary)))
'''
REPLAY_NEW = '''                try:
                    aggregate = self.stage_personal_batch(peer_id,
                        strict_json(self._decrypt(row[0], "personal_batch", primary)))
                except self._ConflictingAttachmentManifest:
                    # A previously staged invalid ordinary group must not block
                    # other groups. Keep its original rows for normal expiry.
                    continue
'''
def replace(source, old, new):
    assert source.count(old) == 1
    return source.replace(old, new)

def fnv(source):
    h = 14695981039346656037
    for byte in source.encode():
        h = ((h ^ byte) * 1099511628211) & ((1 << 64) - 1)
    return f'{h:016x}'

def method(source, name, next_name):
    return source[source.index('    def '+name+'('):source.index('    def '+next_name+'(')]

def canonical(x): return json.dumps(x, sort_keys=True, separators=(',', ':')).encode()
def strict_json(x): return json.loads(x)
def b64(x): return base64.b64encode(x).decode()
def now_ms(): return 1000
# Same ordering and digest contract; canonical serialization is a test double.
def records_hash(records):
    keys = [(item.get("kind"), item.get("id")) for item in records]
    if keys != sorted(set(keys), key=lambda item: (item[0].encode(), item[1].encode())):
        raise ValueError("invalid personal sync record ordering")
    return hashlib.sha256(canonical(records)).hexdigest()
personal_sync_contract = types.SimpleNamespace(validate_selected_records=lambda *a: None)
personal_actor_contract = types.SimpleNamespace(is_storage_peer=lambda p: p.startswith('actor:'))
SCHEMA = '''CREATE TABLE inbox(message_id TEXT NOT NULL, peer_id TEXT NOT NULL, kind TEXT NOT NULL,
 received_ms INTEGER NOT NULL, expires_ms INTEGER NOT NULL, payload BLOB NOT NULL,
 state TEXT NOT NULL, PRIMARY KEY(peer_id,message_id));
 CREATE TABLE dedupe(message_id TEXT NOT NULL, peer_id TEXT NOT NULL, result TEXT NOT NULL,
 error TEXT NOT NULL, seen_ms INTEGER NOT NULL, PRIMARY KEY(peer_id,message_id));
 CREATE TABLE meta(key TEXT PRIMARY KEY, value BLOB NOT NULL);
 CREATE TABLE personal_batch(peer_id TEXT NOT NULL,run_id TEXT NOT NULL,reply INTEGER NOT NULL,
 sequence INTEGER NOT NULL,batch_id TEXT NOT NULL UNIQUE,message_id TEXT NOT NULL UNIQUE,
 received_ms INTEGER NOT NULL,expires_ms INTEGER NOT NULL,payload BLOB NOT NULL,last INTEGER NOT NULL,
 commit_token TEXT NOT NULL, PRIMARY KEY(peer_id,run_id,reply,sequence));'''
class Store:
    def __init__(self, path):
        self.database_path = path
        self.crypto = AESGCM(b'k'*32)
        with sqlite3.connect(path) as db: db.executescript(SCHEMA)
    def personal_run(self, *args): return {'modules':['notes']}
    def _encrypt(self, raw, kind, key):
        nonce = os.urandom(12)
        return nonce + self.crypto.encrypt(nonce, raw, (kind+':'+key).encode())
    def _decrypt(self, raw, kind, key):
        return self.crypto.decrypt(raw[:12], raw[12:], (kind+':'+key).encode())
    def snapshot(self):
        with sqlite3.connect(self.database_path) as db:
            return tuple(db.execute('SELECT * FROM '+t+' ORDER BY 1,2').fetchall() for t in ('personal_batch','inbox','dedupe','meta'))

def variant(stage, ready, fixed):
    if fixed:
        stage = CLASS + replace(replace(stage, INIT, INIT+ADD), CHECK_AT, CHECK_AT+CHECK)
        ready = replace(ready, REPLAY, REPLAY_NEW)
    ns = dict(globals())
    exec('class Product(Store):\n'+stage+ready, ns)
    return ns['Product']

def record(i, size=3, mime='image/png', digest='a'*64):
    value = {'title':i,'text':'','html':'','notebook_id':'','symbol':'','created_ms':1,'modified_ms':1,
             'attachments':[{'sha256':digest,'size':size,'mime':mime,'kind':'image','attachment_id':'a'+i,'name':i+'.png'}]}
    return {'kind':'note','id':i,'state':'live','clock':[{'actor_id':'12345678-1234-4234-8234-123456789abc','counter':1}],
            'modified_ms':1,'hash':hashlib.sha256(canonical(value)).hexdigest(),'value':value}
def uid(label): return str(uuid.UUID(bytes=hashlib.sha256(label.encode()).digest()[:16],version=4))
def messages(run, records, grouped=False, reply=False, fmt=2):
    groups = [[r] for r in records] if grouped else [records]
    if fmt==1:
        for r in records:
            r['value'].pop('attachments',None)
            r['hash']=hashlib.sha256(canonical(r['value'])).hexdigest()
    return [{'kind':'personal_sync.batch','message_id':uid(f'{run}-{reply}-{i}'), 'expires_ms':1000000,
      'body':{'format':fmt,'run_id':uid(run),'batch_id':uid(f'b-{run}-{reply}-{i}'),'sequence':i,'last':i==len(groups)-1,
      'reply':reply,'records':rs,**({'records_hash':records_hash(records)} if fmt>=2 else {})}} for i,rs in enumerate(groups)]
def conflict(store, grouped, field, reverse):
    good=record('a'); bad=record('b',**({'size':4} if field=='size' else {'mime':'image/jpeg'}))
    if reverse:
        good['value'],bad['value']=bad['value'],good['value']
        good['hash'],bad['hash']=bad['hash'],good['hash']
    items=messages('run',[good,bad],grouped)
    if grouped: store.stage_personal_batch('p',items[0])
    before=store.snapshot()
    try: store.stage_personal_batch('p',items[-1]); rejected=False
    except ValueError: rejected=True
    return rejected and before==store.snapshot()
def historical(store, original):
    store.__class__=original
    for m in messages('bad',[record('a'),record('b',size=4)],True): store.stage_personal_batch('p',m)
    store.__class__=target
    store.stage_personal_batch('p',messages('good',[record('c')])[0])
    before=store.snapshot()
    ready=store.ready_personal_batches()
    return [a['run_id'] for _,a in ready]==[uid('good')] and before==store.snapshot()
def valid(store, records, grouped=False, peer='p', fmt=2):
    for m in messages('good',records,grouped,fmt=fmt): a=store.stage_personal_batch(peer,m)
    before=store.snapshot()
    replay=store.ready_personal_batches()
    return a['records']==records and replay[0][1]['commit_token']==a['commit_token'] and store.snapshot()==before

def run(stage, ready):
    original=variant(stage,ready,False)
    tests=[(f'{field}-{grouped}-{reverse}',lambda s,g=grouped,f=field,r=reverse:conflict(s,g,f,r))
           for field in ('size','mime') for grouped in (False,True) for reverse in (False,True)]
    tests += [('historical replay',lambda s:historical(s,original)),
        ('identical hash different names',lambda s:valid(s,[record('a'),record('b')],True)),
        ('distinct hashes',lambda s:valid(s,[record('a'),record('b',size=4,digest='b'*64)])),
        ('actor path unchanged',lambda s:valid(s,[record('a'),record('b',size=4)],True,'actor:p')),
        ('format 1 unchanged',lambda s:valid(s,[record('a'),record('b',size=4)],fmt=1))]
    totals=[]
    for fixed in (False,True):
        global target
        target=variant(stage,ready,fixed)
        passed=0
        for name,test in tests:
            with tempfile.TemporaryDirectory() as d:
                try: ok=bool(test(target(str(Path(d)/'test.sqlite'))))
                except Exception as e: ok=False; print(type(e).__name__,str(e))
            passed+=ok
            print('candidate' if fixed else 'original',name,'PASS' if ok else 'FAIL')
        totals.append(passed)
        print(passed,'/',len(tests))
    assert totals==[4,13],totals
if __name__=='__main__':
    source=Path(sys.argv[1]).read_text()
    stage=method(source,'stage_personal_batch','stage_personal_domain')
    ready=method(source,'ready_personal_batches','dedupe_result')
    assert (fnv(stage),fnv(ready))==('fc30c9907ad58a44','299edb75c439d139')
    run(stage,ready)
