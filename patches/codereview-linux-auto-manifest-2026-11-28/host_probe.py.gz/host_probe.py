"""Extract the real grouped sender and staging methods; isolated host, not full product."""
import ast
import base64
import hashlib
import json
import pathlib
import sqlite3
import sys
import tempfile
import textwrap
import types
import uuid
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
import os

OLD = '''        descriptors = {item["sha256"]: item for record in records if record["kind"] == "note"
                       for item in record["value"]["attachments"]}'''
NEW = '''        descriptors = {}
        for record in records:
            if record["kind"] != "note":
                continue
            for item in record["value"]["attachments"]:
                previous = descriptors.get(item["sha256"])
                if previous is not None and (previous["size"], previous["mime"]) != (item["size"], item["mime"]):
                    raise ValueError("conflicting attachment manifest")
                descriptors[item["sha256"]] = item'''
DDL = '''CREATE TABLE outbox(message_id TEXT PRIMARY KEY, peer_id TEXT NOT NULL, kind TEXT NOT NULL,
created_ms INTEGER NOT NULL, expires_ms INTEGER NOT NULL, payload BLOB NOT NULL,
attempts INTEGER NOT NULL, next_attempt_ms INTEGER NOT NULL, last_error TEXT NOT NULL,
transport_policy TEXT NOT NULL DEFAULT 'any');
CREATE TABLE meta(key TEXT PRIMARY KEY, value BLOB NOT NULL);
CREATE TABLE personal_attachment_transfer(peer_id TEXT NOT NULL,run_id TEXT NOT NULL,reply INTEGER NOT NULL,
records_hash TEXT NOT NULL,sha256 TEXT NOT NULL,direction TEXT NOT NULL,size INTEGER NOT NULL,mime TEXT NOT NULL,
transport_policy TEXT NOT NULL,expires_ms INTEGER NOT NULL,complete INTEGER NOT NULL DEFAULT 0,metadata BLOB,
PRIMARY KEY(peer_id,run_id,reply,records_hash,sha256,direction));
CREATE TABLE personal_attachment_chunk(peer_id TEXT NOT NULL,run_id TEXT NOT NULL,reply INTEGER NOT NULL,
records_hash TEXT NOT NULL,sha256 TEXT NOT NULL,direction TEXT NOT NULL,chunk_index INTEGER NOT NULL,payload BLOB NOT NULL,
PRIMARY KEY(peer_id,run_id,reply,records_hash,sha256,direction,chunk_index));'''

def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def records_hash(records):
    assert [(r['kind'], r['id']) for r in records] == sorted(set((r['kind'], r['id']) for r in records))
    return digest(canonical(records))

def mime_from_magic(raw):
    return 'image/png' if raw.startswith(b'\x89PNG\r\n\x1a\n') else 'application/pdf' if raw.startswith(b'%PDF-') else None

def decode_attachment_data_url(value):
    mime, encoded = value[5:].split(';base64,')
    raw = base64.b64decode(encoded, validate=True)
    assert mime_from_magic(raw) == mime
    return mime, raw

def validate_personal_sync_body(kind, body):
    # Fixture-only double. The separate regression uses the full product validator.
    assert kind in ('personal_sync.request', 'personal_sync.batch') and body['format'] == 2
    for record in body.get('records', []):
        assert record['hash'] == digest(canonical(record['value']))
        for item in record['value']['attachments']:
            assert item['size'] > 0 and len(item['sha256']) == 64

personal_sync_contract = types.SimpleNamespace(validate_selected_records=lambda *a, **k: None)
personal_sync_grants_needed = lambda *a: {'personal_notes_sync'}
negotiated_personal_notes_format = lambda p: 2
supports_personal_format = lambda *a: True
now_ms = lambda: 100000
CHUNK_RAW, DAY_MS = 180000, 86400000

def extract(source, name):
    nodes = [n for n in ast.walk(ast.parse(source)) if isinstance(n, ast.FunctionDef) and n.name == name]
    assert len(nodes) == 1
    node = nodes[0]
    return ''.join(source.splitlines(keepends=True)[node.lineno-1:node.end_lineno])

def fnv(s):
    h = 0xcbf29ce484222325
    for b in s.encode():
        h = ((h ^ b) * 0x100000001b3) & (2**64-1)
    return f'{h:016x}'

def compile_method(source):
    ns = dict(globals())
    exec(compile(textwrap.dedent(source), '<product-method>', 'exec'), ns)
    return ns[ast.parse(textwrap.dedent(source)).body[0].name]

class Store:
    def __init__(self, path):
        self.database_path = path
        self.key = AESGCM(AESGCM.generate_key(bit_length=128))
        with sqlite3.connect(path) as db:
            db.executescript(DDL)
    def _encrypt(self, raw, kind, primary):
        nonce = os.urandom(12)
        return nonce + self.key.encrypt(nonce, raw, canonical([kind, primary]))
    def _attachment_primary(self, *args): return list(args)
    def _attachment_metadata(self, *args): return list(args)
    def _encrypt_attachment_metadata(self, value): return self._encrypt(canonical(value), 'metadata', '')
    def peer(self, _):
        grants = {'grants': {'personal_notes_sync': True}}
        return {'state': 'paired', 'local_grants': grants, 'grants': grants,
                'personal_sync': {'own_device': True, 'remote_own_device': True}}
    def sole_peer(self, p): return p
    def active_auto_run(self, _): return False
    def remember_personal_run(self, p, body):
        with sqlite3.connect(self.database_path) as db:
            db.execute('INSERT INTO meta VALUES (?,?)', (body['run_id'], canonical(body)))
    def set_active_auto_run(self, *args): pass
    def counts(self):
        with sqlite3.connect(self.database_path) as db:
            return tuple(db.execute('SELECT COUNT(*) FROM '+t).fetchone()[0] for t in
                         ('meta','outbox','personal_attachment_transfer','personal_attachment_chunk'))

class Service:
    connections = {}
    connection_transports = {}
    def _note_direction_allowed(self, *args): return True

RAW = b'\x89PNG\r\n\x1a\nfixture'
PDF = b'%PDF-fixture'
def descriptor(raw, name, mime='image/png'):
    return dict(attachment_id=name, name=name, kind='image' if mime.startswith('image/') else 'pdf',
                mime=mime, size=len(raw), sha256=digest(raw))
def record(i, items):
    value = dict(title='note', text='', html='', notebook_id='', symbol='', created_ms=1, modified_ms=2, attachments=items)
    return dict(kind='note', id=str(i), state='live', clock=[dict(actor_id='00000000-0000-4000-8000-000000000001', counter=1)],
                hash=digest(canonical(value)), modified_ms=2, value=value)

def run_case(send, name, groups, raw_sources, reject):
    req = dict(format=2, run_id=str(uuid.uuid4()), trigger='auto_wifi', modules=['notes'])
    records = [r for group in groups for r in group]
    batches = [dict(format=2, run_id=req['run_id'], batch_id=str(uuid.uuid4()), sequence=i, last=i==len(groups)-1,
                    reply=False, records=g, records_hash=records_hash(records)) for i,g in enumerate(groups)]
    sources = [dict(sha256=digest(raw), data='data:'+mime_from_magic(raw)+';base64,'+base64.b64encode(raw).decode()) for raw in raw_sources]
    with tempfile.TemporaryDirectory() as tmp:
        service = Service()
        service.store = Store(str(pathlib.Path(tmp)/'phone.db'))
        error = None
        try: send(service, 'peer', req, batches, sources)
        except ValueError as exc: error = str(exc)
        counts = service.store.counts()
    good = (error == 'conflicting attachment manifest' and counts == (0,0,0,0)) if reject else (error is None and counts == (1,1+len(groups),len(raw_sources),len(raw_sources)))
    print(f'{name}: {"PASS" if good else "FAIL"} counts={counts} error={error}')
    return good

def main():
    source = pathlib.Path(sys.argv[1]).read_text()
    sender, store = (extract(source, n) for n in ('_send_personal_sync_run','queue_format2_run'))
    assert fnv(sender) == '3b36d7a82c9a491c' and fnv(store) == '40cec0c6f9e9ee9f'
    assert sender.count(OLD) == 1
    Store.queue_format2_run = compile_method(store)
    a,b = descriptor(RAW,'a.png'),descriptor(RAW,'b.png')
    wrong_size = dict(a,size=a['size']+1)
    wrong_mime = dict(a,mime='application/pdf',kind='pdf')
    cases = [
        ('size same batch',[[record(1,[wrong_size]),record(2,[b])]], [RAW], True),
        ('size cross batch',[[record(1,[wrong_size])],[record(2,[b])]], [RAW], True),
        ('mime same batch',[[record(1,[wrong_mime]),record(2,[b])]], [RAW], True),
        ('mime cross batch',[[record(1,[wrong_mime])],[record(2,[b])]], [RAW], True),
        ('size reversed',[[record(1,[b]),record(2,[wrong_size])]], [RAW], True),
        ('mime reversed',[[record(1,[b]),record(2,[wrong_mime])]], [RAW], True),
        ('valid repeated same batch',[[record(1,[a]),record(2,[b])]], [RAW], False),
        ('valid repeated cross batch',[[record(1,[a])],[record(2,[b])]], [RAW], False),
        ('distinct hashes',[[record(1,[a]),record(2,[descriptor(PDF,'c.pdf','application/pdf')])]], [RAW,PDF], False),
        ('empty attachments',[[record(1,[])]], [], False),
    ]
    for label, method in [('before',sender),('after',sender.replace(OLD,NEW))]:
        print(label, 'sender FNV', fnv(method), 'store FNV', fnv(store))
        results = [run_case(compile_method(method),*case) for case in cases]
        print(f'{label}: {sum(results)}/{len(results)}')
        if label == 'after': assert all(results)

if __name__ == '__main__': main()
