MAGNOLIE ORGANIZER - WERBEMATERIAL
Stand: 11. November 2026

Kernbotschaft:
Kostenlos. Open Source. Uneingeschränkt nutzbar.
Dein Alltag. Seite für Seite.

Werbeseite:
https://maik3531.github.io/Magnolie-Organizer/
English:
https://maik3531.github.io/Magnolie-Organizer/en/

Enthalten sind deutsch- und englischsprachige Vorlagen, sachliche
Verzeichniseinträge und kurze Beiträge für alle 20 Oberflächensprachen.
Die Übersetzungen sind redaktionelle Entwürfe, keine bestätigte
muttersprachliche Abnahme. Die obersorbische Fassung (hsb) ist ausdrücklich
für sprachkundige Prüfung markiert. Vor einer Veröffentlichung die Regeln
des jeweiligen Kanals beachten und jeweils eine passende Fassung wählen.

Linux: Flatpak, AppImage, DEB, RPM. Windows: Installer/Portable.
macOS ist als Beta gekennzeichnet. Android: separate App Magnolie Notes.
Die Quellen-Datei enthält offizielle Produkt- und Lizenznachweise.

Aktuell ergänzte Alltagsthemen:
- Gesundheits-Reiter: Messwerte, Medikamentenplan, Verlauf, druckbare Übersichten.
- Magnolie Notes: Android-Notizen und Aufgaben, eigener gekoppelter Abgleich.
- KDE Connect: getrennte, optionale Smartphone-Anbindung.
- Auf Wunsch Wetter, Feiertage und Ferien.
- Schichtplanung, Müllabfuhrtermine und Regel-/Zykluskalender.
- Aktive Weiterentwicklung, Fehlerkorrekturen und neue Funktionen.

Keine eingebauten Nutzungsgrenzen bedeutet nicht, dass alle Plattformen
bereits denselben Funktionsumfang haben. Insbesondere macOS bleibt Beta;
Magnolie Notes ist die separate mobile Begleitapp.

Produktbilder sind echte Aufnahmen aus dem Projekt bzw. die vom
Projektinhaber bereitgestellte leere Gesundheitsansicht. Es sind keine
fingierten Nutzerberichte oder Reichweitenzahlen enthalten.
